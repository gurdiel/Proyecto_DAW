
<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <?php if(Auth::user()->administrador): ?>
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/admin/users/vista')); ?>">Edición</a></li>
    <?php endif; ?>
    <li class="breadcrumb-item" aria-current="page">Editar Usuario</li>
  </ol>
</nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-header text-warning">EDITANDO...</div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/admin/escolares/'.$usuario->id)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group row justify-content-center">
                        <div class="col-md-4 justify-content-center">
                    <?php if($usuario->foto): ?>
                    <img src="/images/<?php echo e($usuario->foto->ruta_foto); ?>" width="50%"/>
                    <?php else: ?> <img src="/images/nofoto.jpg" width="50%"/>
                    <?php endif; ?>
                        </div>
                    </div>
                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e($usuario->nombre); ?>" required autocomplete="nombre" autofocus>

                                <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="clase_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Clase')); ?></label>

                            <div class="col-md-6">
                                <input id="clase_id" type="number" class="form-control <?php if ($errors->has('clase_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('clase_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="clase_id" value="<?php echo e($usuario->clase_id); ?>" required autocomplete="clase_id">

                                <?php if ($errors->has('clase_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('clase_id'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('ID')); ?></label>

                            <div class="col-md-6">
                                <input id="id" type="number" class="form-control <?php if ($errors->has('id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="id" value="<?php echo e($usuario->id); ?>" readonly>

                                <?php if ($errors->has('id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="puntos" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Puntos')); ?></label>

                            <div class="col-md-6">
                                <input id="puntos" type="number" class="form-control <?php if ($errors->has('puntos')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('puntos'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="puntos" value="<?php echo e($usuario->puntos); ?>" required autocomplete="puntos">

                                <?php if ($errors->has('puntos')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('puntos'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                        Seleciona un item:

                                <select id="heroe" name="heroe">

                                <option value="">Elige una opción</option>

                                <option value="3">Iron Man</option>

                                <option value="1">Capitán América</option>

                                <option value="4">Hulk</option>

                                <option value="2">Thor</option>

                                </select>
                        </div>                 
                        <div class="centrado pad">
                            <div class="centrado">
                                <button type="submit" class="btn btn-warning">
                                    <?php echo e(__('Confirmar edición')); ?>

                                </button>
                            </div>
                        </div>
                    </form>

                    <div class="container pad text-success">Items en propiedad</div>
                    <?php if(!empty($items)): ?>
                            <div class="form-group row justify-content-center">
                                <div class="col-7 justify-content-center">
                                    <div class="table-responsive justify-content-center">
                                        <table class="table table-responsive table-striped table-bordered table-hover">
                                            <tr>
                                    <th>Heroe</th>
                                    <th>Opción</th>
                                </tr>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
		                            <td>
                                    <img src="/images/<?php echo e($item->fotoitem->ruta_foto); ?>" width="50%"/>
                                    </td>
                                    <td>
                                    <form method="POST" action="<?php echo e(url('/admin/escolares/'.$item->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" onclick="return confirm('¿Desea borrarlo?');" class="btn btn-warning">
                                    <?php echo e(__('Canjear por puntos')); ?>

                                    </button>
                                    </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(sizeof($items)==0): ?>
                            <tr><td></td><td>
                            <div class="form-group row justify-content-center text-info">
                             <?php echo e('No tiene items'); ?>

                            </div>
                            </td></tr>

                            <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Proyecto_DAW/resources/views/admin/escolares/edit.blade.php ENDPATH**/ ?>