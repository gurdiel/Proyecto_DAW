<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/code/Proyecto_DAW/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>