<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item" aria-current="page">Alumnos</li>
  </ol>
</nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
    <p>Estos son los alumnos del <?php echo e($clase->nombre); ?></p> 
        <div class="col-md-10">
        
        <table class="table table-hover">

                        <tr>
                            <th class="tdth2" scope="col">ID Clase</th>
                            <th class="tdth2" scope="col">Nombre</th>
                            <th class="tdth1" scope="col">Pts.</th>
                            <th class="tdth2" scope="col">Items</th>
                            <th class="tdth2" scope="col">Núm. Usuario</th>
                            <th class="tdth2" scope="col">Opciones</th>
                        </tr>
                        <tbody>
                        <?php if($alumnos): ?>
                            <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($alumno->clase_id == $clase->id): ?>

                                    <tr>
                                        <td class="tdth1"><?php echo e($alumno->id); ?></td>
                                        <td class="tdth2"><?php echo e($alumno->user->name); ?></td>
                                        <td class="tdth1"><?php echo e($alumno->puntos); ?></td>
                                        <td class="tdth2">
                                        <?php $__currentLoopData = $alumno->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <img src="../../images/<?php echo e($items->fotoitem->ruta_foto); ?>" width="30%"/></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </td>

                                        <td class="tdth1"><?php echo e($alumno->user_id); ?></td>
                                        <td class="tdth2" style="vertical-align:middle;">
                            <a href="<?php echo e(route('escolares.edit',$alumno->user_id)); ?>" class="btn btn-warning">Editar</a>
                            <form method="POST" action="<?php echo e(url('/admin/docentes/'.$alumno->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" onclick="return confirm('BORRAR?');" class="btn btn-danger">
                                    <?php echo e(__('Eliminar')); ?>

                                </button>
                            </form>
                            </td>
                                        
                                    </tr>
                                    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
        </table>

            <div class="d-flex justify-content-center pad">
                <a href="<?php echo e(route('escolares.create',$clase->id)); ?>" class="card-link bg-success text-dark">Añadir Escolar</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_DAW\resources\views/admin/escolares/index.blade.php ENDPATH**/ ?>