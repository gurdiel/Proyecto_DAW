<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/admin/clases/')); ?>">Clases</a></li>
    <li class="breadcrumb-item" aria-current="page">Editar Clase</li>
  </ol>
</nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-info"><?php echo e(__('Editando clase: ')); ?><?php echo e($clase->nombre); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('admin/clases/'.$clase->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>


                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre:')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e($clase->nombre); ?>" required autocomplete="nombre" autofocus>

                                <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="horarios" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Horarios:')); ?></label>

                            <div class="col-md-6">
                                <input id="horarios" type="text" class="form-control <?php if ($errors->has('horarios')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('horarios'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="horarios" value="<?php echo e($clase->horarios); ?>" required autocomplete="horarios" autofocus>

                                <?php if ($errors->has('horarios')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('horarios'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="anuncios" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Anuncios:')); ?></label>

                            <div class="col-md-6">
                                <input id="anuncios" type="text" class="form-control <?php if ($errors->has('anuncios')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('anuncios'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="anuncios" value="<?php echo e($clase->anuncios); ?>" required autocomplete="anuncios" autofocus>

                                <?php if ($errors->has('anuncios')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('anuncios'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="docente_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Docente id.:')); ?></label>

                            <div class="col-md-6">
                                <input id="docente_id" type="number" class="form-control <?php if ($errors->has('docente_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('docente_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="docente_id" value="<?php echo e($clase->docente_id); ?>" required autocomplete="docente_id" autofocus>
                                <?php if ($errors->has('docente_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('docente_id'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success text-dark">
                                    <?php echo e(__('Confirmar Edición')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_DAW\resources\views/admin/clases/edit.blade.php ENDPATH**/ ?>