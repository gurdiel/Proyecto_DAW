<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fotoitem extends Model
{
    //
    protected $fillable= ['ruta_foto'];
}
