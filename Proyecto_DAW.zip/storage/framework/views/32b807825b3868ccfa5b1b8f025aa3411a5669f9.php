<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    <li class="breadcrumb-item" aria-current="page">Inicio</li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-warning text-center">
                    <h2>Panel de control del <?php echo e(Auth::user()->role->nombre); ?></h2>
                </div>
                <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>


                            <!--Panel de control del administrador-->
                        <?php if(Auth::user()->role_id == 1): ?>
                            <spam class="text-success">Bienvenido, <?php echo e(Auth::user()->name); ?> que deseas hacer?</spam>
                   
                                <div class="list-group grupo">
                                    <a href="<?php echo e(url('/admin/users/')); ?>" class="list-group-item list-group-item-action text-info card text-center">Listar usuarios</a>
                                    <a href="<?php echo e(url('admin/users/create')); ?>" class="list-group-item list-group-item-action text-info card text-center">Crear usuario</a>
                                    <a href="<?php echo e(url('admin/users/vista')); ?>" class="list-group-item list-group-item-action text-info card text-center">Modificar/Eliminar usuario</a>
                                    <a href="<?php echo e(url('/admin/mensajes/')); ?>" class="list-group-item list-group-item-action text-info card text-center">Listar Mensajes</a>
                                    <a href="<?php echo e(url('/admin/clases/')); ?>" class="list-group-item list-group-item-action text-info card text-center">Listar Clases</a>
                                </div>

                            <!--Panel de control del docente.-->
                        <?php elseif(Auth::user()->role_id == 2): ?>

                            <?php if(count($clases) !=0): ?>
                                <div class="container grupo pad">
                                
                                        <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row pad">
                                            
                                                <div class="col-3">
                                                   Aula: <?php echo e($clase->nombre); ?>

                                                </div>
                                                <div class="div col-9 peq1">
                                                    Comentarios: <?php echo e($clase->horarios); ?>

                                                </div>
                                            </div>
                                            <div class="row pad">

                                                <div class="col-4">
                                                    <a href="<?php echo e(route('escolares.show', $clase->id)); ?>" class="list-group-item list-group-item-action list-group-item-danger peq">Ver Alumnos</a>
                                                </div>
                                                <div class="col-4">
                                                    <a href="<?php echo e(route('mensajes.show', $clase->id)); ?>" class="list-group-item list-group-item-action list-group-item-warning peq">Mensajes</a>
                                                </div>
                                                <div class="col-4">
                                                    <a href="archivos/<?php echo e($clase->horario->ruta_horario); ?>" target="blank_" class="list-group-item list-group-item-action list-group-item-warning peq">Ver Horario</a>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="container grupo pad">
                                        <div class="row pad">
                                            <div class="col-12 text-info">
                                                <div class="d-flex justify-content-center pad">
                                                    <p class="text-warning">No tiene clase. Puede empezar a crear su clase...</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                    <div class="container grupo pad">
                                        <div class="row pad">
                                            <div class="col-12 text-info">
                                                <div class="d-flex justify-content-center pad">
                                                    <a href="<?php echo e(route('clases.create')); ?>" class="btn btn-success text-dark">Nueva Clase</a>
                                                </div>
                                            </div>
                                        </div>                                
                                    </div>


                            <?php elseif(Auth::user()->role_id == 3): ?>
                            <spam class="text-success">Bienvenido, <?php echo e(Auth::user()->name); ?>:</spam>
                            
                                <?php if(count($hijos) !=0): ?>
                                    <?php $__currentLoopData = $hijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <div class="container grupo text-center">
                                            <p class="text-info">Tu hijo <?php echo e($hijo->user->name); ?> va a la clase: <?php echo e($hijo->clase->nombre); ?></p>
                                                <div class="row grupo justify-content-center">
                                                        <div class="col-3">
                                                            <a href="<?php echo e(route('mensajes.show', $hijo->clase->id)); ?>" class="list-group-item list-group-item-action list-group-item-info peq">Ver Mensajes</a>
                                                        </div>
                                                        <div class="col-3">
                                                            <a href="<?php echo e(route('users.show', $hijo->id)); ?>" class="list-group-item list-group-item-action list-group-item-warning peq">Ver Logros</a>
                                                        </div> 
                                                        <div class="col-3">
                                                            <a href="archivos/<?php echo e($hijo->clase->horario->ruta_horario); ?>" target="blank_" class="list-group-item list-group-item-action list-group-item-warning peq">Ver Horario</a>
                                                        </div>
                                                        <div class="col-3">
                                                            <a href="archivos/<?php echo e($hijo->nota->ruta_nota); ?>" target="blank_" class="list-group-item list-group-item-action list-group-item-info peq">Ver Notas</a>
                                                        </div>
                                                </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <div class="container grupo pad">
                                    <div class="row pad">
                                        <div class="col-12 text-info">
                                            <div class="d-flex justify-content-center pad">
                                                <p class="text-warning">No tiene asignado ningún alumno. Espere que desde el centro creen el perfil.</p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>       
                                <!--Presentación de los ítems del escolar.-->
                            <?php elseif(Auth::user()->role_id == 4): ?>
                            <spam class="text-success grande">Bienvenido <?php echo e(Auth::user()->name); ?>! , estos son tus ítems:</spam>
                                    <!--<div class="row">
                                        <div class="col-12">-->
                                    <div class="card-group padtop">
                                        <div class="row justify-content-center">
                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->escolare_id == $escolar->id): ?>
                                                
                                                    <div class="card col-md-8 col-lg-8 col-xl-8">
                                                        
                                                        <img class="card-img-top" src="images/<?php echo e($item->fotoitem->ruta_foto); ?>" alt="<?php echo e($item->id); ?>">
                                                        
                                                    </div>
                                                
                                                <!--<body onload="return alert('No tienes ningún item aún. CONSIGUELOS!');">-->
                                                <?php endif; ?>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($items) == 0): ?>
                                            esto sale
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="card-group padtop">
                                    <p class="text-warning">Te quedan <?php echo e($escolar->puntos); ?> puntos.</p>
                                    </div>
                                        <!--
                                            <?php echo e(Auth::user()->escolare->clase->anuncios); ?>


                                            <div class="container">
                                                <div class="row justify-content-center">
                                            
                                                    <div class="col-md-10 pad">
                                                    
                                                        <table class="table table-hover">

                                                                    <tr>
                                                                        <th class="tdth1" scope="col">ID Clase</th>
                                                                        <th class="tdth2" scope="col">Nombre</th>
                                                                        <th class="tdth1" scope="col">Pts.</th>
                                                                        <th class="tdth2" scope="col">Items</th>
                                                                        <th class="tdth1" scope="col">User</th>
                                                                    </tr>
                                                                    <tbody>
                                                                                <tr>
                                                                                    <td class="tdth1"><?php echo e($escolar->id); ?></td>
                                                                                    <td class="tdth2"><?php echo e($escolar->user->name); ?></td>
                                                                                    <td class="tdth1"><?php echo e($escolar->puntos); ?></td>
                                                                                    <td class="tdth2">
                                                                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($item->escolare_id == $escolar->id): ?>
                                                                                        <img src="images/<?php echo e($item->fotoitem->ruta_foto); ?>" width="50%"/>
                                                                                    <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </td>
                                                                                    <td class="tdth1"><?php echo e($escolar->user_id); ?></td>
                                                                                    
                                                                                </tr>
                                                                                
                                                                    </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>-->
                        
                        <?php endif; ?>
                </div>
            </div>
                
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_DAW\resources\views/home.blade.php ENDPATH**/ ?>