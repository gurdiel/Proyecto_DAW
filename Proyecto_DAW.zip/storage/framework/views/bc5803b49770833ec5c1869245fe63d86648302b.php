<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item" aria-current="page">Menu</li>
  </ol>
</nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>


<div class="container grupo">
  <div class="row justify-content-center">
    <div class="col-8">
        <div class="list-group sinfondo">
            <div class="panel-title grande text-warning pad">Registro para progenitores:</div>
            <a href="<?php echo e(url('admin/progenitores/create')); ?>" class="list-group-item list-group-item-action card text-danger text-center">Entrar para registro</a>    
        </div>
        <div class="div pad text-center">
        <button type="button" class="btn btn-info" onclick="location.href='<?php echo e(url()->previous()); ?>';">Atrás</button>
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_DAW\resources\views/admin/users/create.blade.php ENDPATH**/ ?>