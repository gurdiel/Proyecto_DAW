<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item" aria-current="page">Mensajes</li>
  </ol>
</nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<A name="arriba"></A>
<div class="container col-md-8">
<div class="container text-warning grande" style="text-align: center;">Mensajes por clases.</div>

<div class="list-group grupo">
  <?php if($clases): ?>
    <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('mensajes.show', $clase->id)); ?>" class="list-group-item list-group-item-action text-info card text-center"><?php echo e($clase->nombre); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</div>
<div class="container col-md-8 text-center">
<button type="button" class="btn btn-info text-center" onclick="location.href='<?php echo e(url('/home')); ?>';">Atrás</button>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_DAW\resources\views/admin/mensajes/vista.blade.php ENDPATH**/ ?>