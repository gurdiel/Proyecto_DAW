
<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item" aria-current="page">Mensajes</li>
  </ol>
</nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<A name="arriba"></A>
<div class="container text-success grande" style="text-align: center;">

Mensajes del <?php echo e($clase->nombre); ?>

</div>


<?php if($mensajes): ?>
<?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($msn->clase_id == $clase->id): ?>
<div class="card lineado pad">
  <div class="card-body">
    <h5 class="card-title"><spam class="text-info">Titulo:</spam> <?php echo e($msn->titulo); ?></h5>
    <p class="card-text lineado"><p class="text-info">Mensaje:</p> <?php echo e($msn->mensaje); ?></p>
    <?php if(Auth::user()->docente): ?>
    <form method="POST" action="<?php echo e(url('/admin/mensajes/'.$msn->id)); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

        <button type="submit" onclick="return confirm('¿Desea borrar el mensaje?');" class="btn btn-danger">
        <?php echo e(__('Eliminar')); ?>

    </button>
</form>
<?php endif; ?>
  </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class="d-flex justify-content-center pad">
<a href="<?php echo e(route('mensajes.create', $clase->id)); ?>" class="card-link bg-success text-dark">Nuevo Mensaje</a>
</div>
<div class="div pad" style="text-align:center;">
        <button type="button" class="btn btn-info" onclick="location.href='#arriba';">Ir arriba</button>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Proyecto_DAW/resources/views/admin/mensajes/index.blade.php ENDPATH**/ ?>