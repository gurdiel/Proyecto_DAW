<?php $__env->startSection('migasdepan'); ?>
<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item" aria-current="page"><?php echo e($escolar->user->name); ?></li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
                                <div class="container"> 
                                    <div class="row justify-content-center">
                                    
                                        <div class="col-md-10 pad">
                                        
                                        <table class="table table-hover">
                                        <caption>Logros de tu hijo, <?php echo e($escolar->user->name); ?></caption>

                                                        <tr>
                                                            <th class="tdth1" scope="col">ID Clase</th>
                                                            <th class="tdth2" scope="col">Nombre</th>
                                                            <th class="tdth2" scope="col">Apellido</th>
                                                            <th class="tdth1" scope="col">Pts.</th>
                                                            <th class="tdth2" scope="col">Items</th>
                                                            <th class="tdth1" scope="col">User</th>
                                                        </tr>
                                                        <tbody>
                                                                    <tr>
                                                                        <td class="tdth1"><?php echo e($escolar->id); ?></td>
                                                                        <td class="tdth2"><?php echo e($escolar->user->name); ?></td>
                                                                        <td class="tdth2"><?php echo e($escolar->user->lastname); ?></td>
                                                                        <td class="tdth1"><?php echo e($escolar->puntos); ?></td>
                                                                        <td class="tdth2">
                                                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($item->escolare_id == $escolar->id): ?>
                                                                            <img src="../../images/<?php echo e($item->fotoitem->ruta_foto); ?>" width="50%"/>
                                                                        <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </td>
                                                                        <td class="tdth1"><?php echo e($escolar->user_id); ?></td>
                                                                        
                                                                    </tr>
                                                                    
                                                        </tbody>
                                        </table>
                                        </div>
                                    </div>
                                 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_DAW\resources\views/admin/escolares/vista.blade.php ENDPATH**/ ?>