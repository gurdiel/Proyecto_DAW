
<?php $__env->startSection('migasdepan'); ?>

<nav aria-label="breadcrumb migas">
  <ol class="breadcrumb migas">
    
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item active"><a href="<?php echo e(url('/admin/users/vista')); ?>">Edición</a></li>
    <li class="breadcrumb-item" aria-current="page">Editar Usuario</li>
  </ol>
</nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <?php if($usuario->role_id == 2): ?>
                <div class="card-header text-warning">EDITANDO...</div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/admin/users/'.$usuario->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group row justify-content-center">
                        <div class="col-md-4 justify-content-center">
                    <?php if($usuario->foto): ?>
                    <img src="/images/<?php echo e($usuario->foto->ruta_foto); ?>" width="50%"/>
                    <?php else: ?> <img src="/images/nofoto.jpg" width="50%"/>
                    <?php endif; ?>
                        </div>
                    </div>
                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e($usuario->docente->nombre); ?>" required autocomplete="nombre" autofocus>

                                <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($usuario->docente->email); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefono')); ?></label>

                            <div class="col-md-6">
                                <input id="telefono" type="text" class="form-control <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telefono" value="<?php echo e($usuario->docente->telefono); ?>" required autocomplete="telefono" autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="foto_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Foto:')); ?></label>

                            <div class="col-md-6 foto">
                                <input id="foto_id" type="file" name="foto_id" accept="image/png, .jpeg, .jpg, image/gif">
                            </div>
                        </div>
                        <?php elseif($usuario->role_id == 3): ?>

                        <div class="card-header text-primary">EDITANDO...</div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(url('/admin/users/'.$usuario->id)); ?>" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PATCH')); ?>

                                <div class="form-group row justify-content-center">
                                    <div class="col-md-4 justify-content-center">
                                <?php if($usuario->foto): ?>
                                <img src="/images/<?php echo e($usuario->foto->ruta_foto); ?>" width="50%"/>
                                <?php else: ?> <img src="/images/nofoto.jpg" width="50%"/>
                                <?php endif; ?>
                                    </div>
                                </div>
                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e($usuario->progenitore->nombre); ?>" required autocomplete="nombre" autofocus>

                                <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($usuario->progenitore->email); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefono')); ?></label>

                            <div class="col-md-6">
                                <input id="telefono" type="text" class="form-control <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telefono" value="<?php echo e($usuario->progenitore->telefono); ?>" required autocomplete="telefono" autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="foto_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Foto:')); ?></label>

                            <div class="col-md-6 foto">
                                <input id="foto_id" type="file" name="foto_id" accept="image/png, .jpeg, .jpg, image/gif">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fam_aut" class="col-md-4 col-form-label text-md-right"><?php echo e(__('fam_aut')); ?></label>

                            <div class="col-md-6">
                                <input id="fam_aut" type="text" name="fam_aut" class="form-control" value="<?php echo e($usuario->progenitore->fam_aut); ?>"
                                onclick="if(this.value=='Abuelos,cuidador...') this.value=''" onblur="if(this.value=='') this.value='Abuelos,cuidador...'">
                            </div>
                        </div>
                        <?php elseif($usuario->role_id == 3): ?>
                        <div class="card-header text-primary">EDITANDO...</div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/admin/users/'.$usuario->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <div class="form-group row justify-content-center">
                        <div class="col-md-4 justify-content-center">
                    <?php if($usuario->foto): ?>
                    <img src="/images/<?php echo e($usuario->foto->ruta_foto); ?>" width="50%"/>
                    <?php else: ?> <img src="/images/nofoto.jpg" width="50%"/>
                    <?php endif; ?>
                        </div>
                    </div>
                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e($usuario->docente->nombre); ?>" required autocomplete="nombre" autofocus>

                                <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($usuario->docente->email); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefono')); ?></label>

                            <div class="col-md-6">
                                <input id="telefono" type="text" class="form-control <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telefono" value="<?php echo e($usuario->docente->telefono); ?>" required autocomplete="telefono" autofocus>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="foto_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Foto:')); ?></label>

                            <div class="col-md-6 foto">
                                <input id="foto_id" type="file" name="foto_id" accept="image/png, .jpeg, .jpg, image/gif">
                            </div>
                        </div>
                        <?php elseif($usuario->role_id == 4): ?>

                        <div class="card-header text-primary">EDITANDO...</div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(url('/admin/users/'.$usuario->id)); ?>" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PATCH')); ?>

                                <div class="form-group row justify-content-center">
                                    <div class="col-md-4 justify-content-center">
                                <?php if($usuario->foto): ?>
                                <img src="/images/<?php echo e($usuario->foto->ruta_foto); ?>" width="50%"/>
                                <?php else: ?> <img src="/images/nofoto.jpg" width="50%"/>
                                <?php endif; ?>
                                    </div>
                                </div>
                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e($usuario->escolare->nombre); ?>" required autocomplete="nombre" autofocus>

                                <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="clase_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Clase:')); ?></label>

                            <div class="col-md-6">
                                <input id="clase_id" type="number" class="form-control <?php if ($errors->has('clase_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('clase_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="clase_id" value="<?php echo e($usuario->escolare->clase_id); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="progenitore_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Progenitor:')); ?></label>

                            <div class="col-md-6">
                                <input id="progenitore_id" type="number" class="form-control <?php if ($errors->has('progenitore_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('progenitore_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="progenitore_id" value="<?php echo e($usuario->escolare->progenitore_id); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="foto_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Foto:')); ?></label>

                            <div class="col-md-6 foto">
                                <input id="foto_id" type="file" name="foto_id" accept="image/png, .jpeg, .jpg, image/gif">
                            </div>
                        </div>
                        <?php endif; ?>
                        

                        <div class="centrado">
                            <div class="centrado">
                                <button type="submit" class="btn btn-warning">
                                    <?php echo e(__('Confirmar edición')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Proyecto_DAW/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>